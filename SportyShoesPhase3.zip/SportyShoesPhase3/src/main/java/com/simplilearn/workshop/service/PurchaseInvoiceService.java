package com.simplilearn.workshop.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simplilearn.workshop.repository.PurchaseInvoiceRepository;
import com.simplilearn.workshop.model.PurchaseInvoice;

@Service
public class PurchaseInvoiceService {

	@Autowired
	private PurchaseInvoiceRepository purchaseInvoiceRepository;
	
	public void savePurchaseInvoice(String productName, String category, int productPrice, String custName, String custEmail, Date date) {
	
		PurchaseInvoice purchaseInvoice = new PurchaseInvoice(productName, category, productPrice, custName, custEmail, date);
		purchaseInvoiceRepository.save(purchaseInvoice);
	}
	
	public List<PurchaseInvoice> getAllPurchaseInvoice(){
		List<PurchaseInvoice> purchaseInvoices = purchaseInvoiceRepository.findAll();
		return purchaseInvoices;
	}
	
	public List<PurchaseInvoice> getPurchaseInvoiceByCategory(String category) {
		List<PurchaseInvoice> purchaseInvoices= purchaseInvoiceRepository.findAllByCategory(category);
		return purchaseInvoices;
	}
	
	public List<PurchaseInvoice> getPurchaseInvoiceByDate(String date) throws ParseException {
		List<PurchaseInvoice> purchaseInvoices = purchaseInvoiceRepository.findAllByDate(new SimpleDateFormat("yyyy-MM-dd").parse(date));
		return purchaseInvoices;
	}
	}
