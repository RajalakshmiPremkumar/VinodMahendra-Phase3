package com.simplilearn.workshop.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@NoArgsConstructor
@AllArgsConstructor
@Entity
public class PurchaseInvoice {
	
	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;

	private String category;
	
	private String productName;

	private int productPrice;

	private String customer;
	
	private String customerEmail;
	
	@Temporal(TemporalType.DATE)
	private Date purchaseDate;
	
	
	
	public PurchaseInvoice() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PurchaseInvoice(int id, String category, String productName, int productPrice, String customer,
			String customerEmail, Date purchaseDate) {
		super();
		this.id = id;
		this.category = category;
		this.productName = productName;
		this.productPrice = productPrice;
		this.customer = customer;
		this.customerEmail = customerEmail;
		this.purchaseDate = purchaseDate;
	}

	public PurchaseInvoice(String productName , String category, int productPrice, String customer, String customerEmail,
			Date purchaseDate) {
		
		this.category = category;
		this.productName = productName;
		this.productPrice = productPrice;
		this.customer = customer;
		this.customerEmail = customerEmail;
		this.purchaseDate = purchaseDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public int getProductPrice() {
		return productPrice;
	}

	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public Date getPurchaseDate() {
		return purchaseDate;
	}

	public void setPurchaseDate(Date purchaseDate) {
		this.purchaseDate = purchaseDate;
	}
	
	
}
