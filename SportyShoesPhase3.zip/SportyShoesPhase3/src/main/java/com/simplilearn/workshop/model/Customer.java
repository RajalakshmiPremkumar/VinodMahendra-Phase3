package com.simplilearn.workshop.model;

import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Entity
@Table(name = "customer")
public class Customer {


	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int custId;
	
	@Column(name = "name")
	private String custName;
	
	@Column(name = "email")
	private String custEmail;
	
	@Column(name = "pwd")
	private String custPwd;
	
	@ManyToMany(fetch = FetchType.LAZY, cascade = { CascadeType.PERSIST, CascadeType.MERGE })
	@JoinTable(name = "CUSTOMER_PRODUCT", joinColumns = @JoinColumn(name = "CUSTOMER_ID"), inverseJoinColumns = @JoinColumn(name = "PRODUCT_ID"))
	private List<Product> products = new ArrayList<Product>();
	
	
	
	public Customer(int custId, String custName, String custEmail, String custPwd, List<Product> products) {
		super();
		this.custId = custId;
		this.custName = custName;
		this.custEmail = custEmail;
		this.custPwd = custPwd;
		this.products = products;
	}

	
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Customer(String custName, String custEmail) {
		this.custName = custName;
		this.custEmail = custEmail;
		
	}
	
	public void addProduct(Product product) {
		this.products.add(product);
	}
	

	@Override
	public String toString() {
		return "Custom ToString -> Customer [customerId=" + custId + ", customerName=" + custName + ", Customeremail=" + custEmail + ", CustomerPwd="
				+ custPwd + ", Products=" + products + "]";
	}



	public int getCustId() {
		return custId;
	}



	public void setCustId(int custId) {
		this.custId = custId;
	}



	public String getCustName() {
		return custName;
	}



	public void setCustName(String custName) {
		this.custName = custName;
	}



	public String getCustEmail() {
		return custEmail;
	}



	public void setCustEmail(String custEmail) {
		this.custEmail = custEmail;
	}



	public String getCustPwd() {
		return custPwd;
	}



	public void setCustPwd(String custPwd) {
		this.custPwd = custPwd;
	}



	public List<Product> getProducts() {
		return products;
	}



	public void setProducts(List<Product> products) {
		this.products = products;
	}


	
	

	
}
