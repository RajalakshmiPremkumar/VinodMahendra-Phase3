package com.simplilearn.workshop.controller;

import com.simplilearn.workshop.model.Customer;
import com.simplilearn.workshop.model.Product;
import com.simplilearn.workshop.service.*;

import java.security.SecureRandom;
import java.util.Date;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping ("/customers")
public class CustomerController {

	@Autowired
	private CustomerService customerService;

	@Autowired
	private ProductService productService;

	@Autowired
	private PurchaseInvoiceService purchaseInvoiceService;
	
	@PostMapping("/signup")
	public @ResponseBody String register(@RequestBody(required = false) Customer çustomer) {
	
		if (çustomer == null) {
			return "Enter Valid Customer Details - Customer details should not be Null";
		}
		else if(çustomer.getCustPwd() == null || çustomer.getCustEmail()== null || çustomer.getCustName() == null) {
			return "Enter Valid Customer Details - All the fields(Name, Password, Email) are mandatory";
		}
		int strength = 10;
		BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder(strength, new SecureRandom());
		String encodedPassword = bCryptPasswordEncoder.encode(çustomer.getCustPwd());
		çustomer.setCustPwd(encodedPassword);
		çustomer.setCustName(çustomer.getCustName().toLowerCase());
		customerService.signUp(çustomer);
		return "Signed Up Successfully!";
	}
	
	@PostMapping("/{custId}/buy/{productName}")
	@Transactional
	public @ResponseBody String buyProductByName(@PathVariable(name = "custId") int custId,
			@PathVariable(name = "productName") String productName) {
		Optional<Product> product = productService.getProductByName(productName);
		if (product.isPresent()) {
			Optional<Customer> customer = customerService.findCustomerById(custId);
			if (customer.isPresent()) {
				Customer customer2 = customer.get();
				customer2.addProduct(product.get());
				Product product2 = product.get();
				product2.addCustomer(customer.get());
				customerService.saveCustomerWithPrd(customer2);
				productService.addProduct(product2);
				purchaseInvoiceService.savePurchaseInvoice(product2.getProductName(), product2.getCategory(),
						product2.getProductPrice(), customer2.getCustName(), customer2.getCustEmail(), new Date());
				return "You have successfully bought : " + product.get().getProductName();
			} else {
				return "Customer Not Found! Become a Customer to buy the Product";
			}
		}
		return "Product Not Found!";
	}
	
	
	
}
