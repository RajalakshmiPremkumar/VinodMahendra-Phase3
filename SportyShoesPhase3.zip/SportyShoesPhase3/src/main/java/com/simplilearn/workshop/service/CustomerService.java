package com.simplilearn.workshop.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.simplilearn.workshop.model.Customer;
import com.simplilearn.workshop.repository.CustomerRepository;


@Service
public class CustomerService {

	@Autowired
	CustomerRepository customerRepository;
	
	public Customer signUp(Customer customer) {
		
		return customerRepository.save(customer);
	}
	
	public Customer saveCustomerWithPrd(Customer customer) {
		return customerRepository.save(customer);
		
	}
	
	public List<Customer> allCustomers(){
		
		return customerRepository.findAll();
	}
	
	public Optional<Customer> findCustomerByName(String name) {
		Optional<Customer> customer = customerRepository.findCustByName(name);
		return customer;
	}
	
	public Optional<Customer> findCustomerById(int id) {
		Optional<Customer> customer = customerRepository.findById(id);
		return customer;
	}
	
}
