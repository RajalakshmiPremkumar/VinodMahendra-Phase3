package com.simplilearn.workshop.controller;

import java.text.ParseException;
import java.util.List;
import java.util.Optional;
import com.simplilearn.workshop.model.*;
import com.simplilearn.workshop.service.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/admin")
public class AdminController {
	
	@Autowired
	ProductService productService;

	@Autowired
	CustomerService customerService;

	@Autowired
	private PurchaseInvoiceService purchaseInvoiceService;

	@GetMapping("/products")
	public ResponseEntity<List<Product>> getAllProducts() {
		List<Product> allProducts = productService.getAllProducts();
		if (allProducts.isEmpty()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		ResponseEntity<List<Product>> responseEntity = new ResponseEntity<List<Product>>(allProducts, HttpStatus.OK);
		return responseEntity;
	}
	
	@GetMapping("/products/categories/{category}")
	public ResponseEntity<List<Product>> getAllProductsBasedOnCategory(@PathVariable("category") String category) {
		System.out.println("Category to look for -> " + category);
		List<Product> allProductsBasedOnCategory = productService.getAllProductBasedOnCatogary(category);
		if (allProductsBasedOnCategory.isEmpty()) {
			return new ResponseEntity<>(HttpStatus.NO_CONTENT);
		}
		ResponseEntity<List<Product>> responseEntity = new ResponseEntity<List<Product>>(allProductsBasedOnCategory,
				HttpStatus.OK);
		return responseEntity;
	}
	@PostMapping("/products")
	public ResponseEntity<Product> addProduct(@RequestBody Product product) {
		Product temp = productService.addProduct(product);
		if (temp == null) {
			return new ResponseEntity<Product>(HttpStatus.BAD_REQUEST);
		}
		return new ResponseEntity<Product>(temp, HttpStatus.OK);

	}
	@GetMapping("/products/{productId}")
	public ResponseEntity<Product> getProductById(@PathVariable("productId") int id) {
		Optional<Product> product = productService.getProductById(id);
		if (!product.isPresent()) {
			return new ResponseEntity<Product>(HttpStatus.NO_CONTENT);
		}

		return new ResponseEntity<Product>(product.get(), HttpStatus.OK);
	}

	@DeleteMapping("/products/{productId}")
	public ResponseEntity<HttpStatus> deleteById(@PathVariable("productId") int id) {
		productService.deleteProductById(id);
		return new ResponseEntity<>(HttpStatus.OK);
	}
	@GetMapping("/customers")
	public ResponseEntity<List<Customer>> getAllSignedUpCustomers() {
		List<Customer> allSignedUpCustomers = customerService.allCustomers();
		if (allSignedUpCustomers.isEmpty()) {
			return new ResponseEntity<List<Customer>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<Customer>>(allSignedUpCustomers, HttpStatus.OK);

	}
	@GetMapping("/customers/{custName}")
	public ResponseEntity<Customer> getSignedUpUser(@PathVariable String custName) {
		Optional<Customer> signedUpCustomer = customerService.findCustomerByName(custName);
		if (!signedUpCustomer.isPresent()) {
			return new ResponseEntity<Customer>(HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Customer>(signedUpCustomer.get(), HttpStatus.OK);
	}
	@GetMapping("/purchaseinvoice")
	public ResponseEntity<List<PurchaseInvoice>> getPurchaseInvoice() {
		List<PurchaseInvoice> purchaseInvoice = purchaseInvoiceService.getAllPurchaseInvoice();
		if (purchaseInvoice.isEmpty()) {
			return new ResponseEntity<List<PurchaseInvoice>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<PurchaseInvoice>>(purchaseInvoice, HttpStatus.OK);

	}
	@GetMapping("/purchaseinvoice/category/{category}")
	public ResponseEntity<List<PurchaseInvoice>> getPurchaseInvoiceBasedOnCategory(@PathVariable String category) {
		List<PurchaseInvoice> purchaseReportBasedOnCategory = purchaseInvoiceService.getPurchaseInvoiceByCategory(category);
		if (purchaseReportBasedOnCategory.isEmpty()) {
			return new ResponseEntity<List<PurchaseInvoice>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<PurchaseInvoice>>(purchaseReportBasedOnCategory, HttpStatus.OK);

	}
	
	@GetMapping("/purchaseinvoice/date/{date}")
	public ResponseEntity<List<PurchaseInvoice>> getPurchaseReportBasedOnDate(@PathVariable String date) throws ParseException {
		System.out.println("Date from url is : " + date);
		List<PurchaseInvoice> purchaseInvoiceByCateg = purchaseInvoiceService.getPurchaseInvoiceByDate(date);
		if (purchaseInvoiceByCateg.isEmpty()) {
			return new ResponseEntity<List<PurchaseInvoice>>(HttpStatus.NO_CONTENT);
		}
		return new ResponseEntity<List<PurchaseInvoice>>(purchaseInvoiceByCateg, HttpStatus.OK);

	}

}
